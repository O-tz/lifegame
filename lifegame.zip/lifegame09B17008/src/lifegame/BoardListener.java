package lifegame;

public interface BoardListener {
	public void updated(BoardModel m);
	
}
